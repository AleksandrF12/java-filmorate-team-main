package ru.yandex.practicum.filmorate.exceptions;

public class SortingIsNotSupportedException extends RuntimeException{
	public SortingIsNotSupportedException(String m) {
		super(m);
	}
}
